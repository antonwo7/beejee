<?php

require_once('system/config.php');
require_once('system/helper.php');
require_once('system/start.php');

