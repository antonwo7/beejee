<?php
namespace Model;

class Login{
	public function get_fields($args){
		return '';
	}
}

?>