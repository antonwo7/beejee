<?php
Class Controller{
	
	function __construct(){
		
	}
}
?>